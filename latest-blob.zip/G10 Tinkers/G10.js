const express = require("express");
const mysql = require("mysql2");
const bodyparser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyparser.json());

const connection = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "Alphabravo123@",
  database: "nodejs",
});

//Read
app.get('/G10-members',(res,req)=>{
  connection.query('SELECT * FROM nodes',(err,rows, fields)=>{
    if (!err)
    console.log(rows);
    else
    console.log(err);
  })
})

//Create and insert to DB
app.post('/add-member', (req, res) => {
  console.log(req.query);
  // once requested, add users to database.
  // connect to database
  // query insert to database
  connection.query(
    'INSERT INTO nodes (Fname,Lname,Phone,Address1,Address2,Email) VALUES (?,?,?,?,?,?)',
    [req.body.Fname,req.body.Lname,req.body.Phone,req.body.Address1,req.body.Address2,req.body.Email],
    (err,results) => {
      if (results?.affectedRows) {
        res.json({message:"New Member Registered"});
      }
      else{
        res.json({message: err});
      }
    }
  );
});

app.delete('/kick-member',(req,res) =>{
  connection.query(
    'DELETE FROM nodes WHERE id=?',
    [req.body.id],
    (err,results) => {
      if (results?.affectedRows) {
        res.json({message:"G10 Member Kicked"});
      }
      else{
        res.json({message: "Error in Deleting", err});
      }
    }
  );
});

//Update existing column in DB
app.put('/edit-member',(req,res) =>{
  connection.query(
    'UPDATE nodes SET Fname=?,Lname=?,Phone=?,Address1=?,Address2=?,Email=? WHERE id=?',
    [req.body.Fname,req.body.Lname,req.body.Phone,req.body.Address1,req.body.Address2,req.body.Email,req.body.id],
    (err,results) => {
      if (results?.affectedRows) {
        res.json({message:"G10 Member Updated"});
      }
      else{
        res.json({message: err});
      }
    }
  );
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

