const express = require('express');
const app = express();
const bodyParser = require('body-parser');
app.use(bodyParser.json({ limit: "50mb"}));
const mysql = require("mysql");
const port = 3000;
app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }))

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "cameradb",
});


app.post('/motionTime', (req, res) => {
    const {motiontime} = req.body;
    const data = JSON.parse(motiontime);
    
    for (let i = 0; i < data.length; i++) {
        connection.query(
                "INSERT INTO motiontimedb (Motiontime) VALUES (?)", [data[i]]),
            function(err, results) {
                if (err) throw err;
                console.log(req.query);
                console.log(results);
                res.send(results);
                console.log("Test");
            }
    }
    console.log(data)
    return;
    

});

app.post('/motion_detector',(req,res) => {
    const { time_captured, image } = req.body;
    // query insert to database
    //console.log(req.body.time_captured)
    connection.query(
        "INSERT INTO cameradb (Image_Date, Image) VALUES (?,?)",
        [time_captured, image]),
        function (err, results) {
            console.log(results);
            res.json(results);}
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});